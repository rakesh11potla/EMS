import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import ListEmployeeComponent from './components/ListEmployeeComponent';
import HeaderNew from './components/HeaderNew';
import FooterComponent from './components/FooterComponent';
import CreateEmployeeComponent from './components/CreateEmployeeComponent';
import UpdateEmployeeComponent from './components/UpdateEmployeeComponent';
import ViewEmployeeComponent from './components/ViewEmployeeComponent';
import EmployeeComponent from './components/EmployeeComponent';
import HomeComponent from './components/HomeComponent';
import LoginWidget from './Auth/LoginWidget';
import SignupWidget from './Auth/SignupWidget';
import { OktaAuth } from '@okta/okta-auth-js';
import { Security, LoginCallback, SecureRoute } from '@okta/okta-react';
import { oktaConfig } from './lib/oktaConfig';
import AdminComponent from './components/AdminComponent';

const oktaAuth = new OktaAuth(oktaConfig);

const restoreOriginalUri = async (oktaAuth, originalUri) => {
  window.location.replace(originalUri || '/');
};

const App = () => {
  return (
    <Security
      oktaAuth={oktaAuth}
      restoreOriginalUri={restoreOriginalUri}
    >
      <Router>
        <HeaderNew />
        <div className="container">
          <Switch>
            <Route path='/' exact>
              <Redirect to='/home' />
            </Route>
            <Route path='/home'>
              <HomeComponent />
            </Route>
            <Route path="/employees" component={ListEmployeeComponent} />
            <Route path="/admin" component={AdminComponent} />
            <Route path="/add-employee/:id" component={CreateEmployeeComponent} />
            <Route path="/view-employee/:id" component={ViewEmployeeComponent} />
            <Route path="/update-employee/:id" component={UpdateEmployeeComponent} />
            <Route path='/login' render={() => <LoginWidget config={oktaConfig} />} />
            <Route path='/signup' render={() => <SignupWidget />} />
            <Route path='/login/callback' component={LoginCallback} />
            <SecureRoute path='/employees' component={ListEmployeeComponent} />
            <SecureRoute path='/home' component={ListEmployeeComponent} />
            <SecureRoute path='/admin' component={AdminComponent} />
            <SecureRoute path='/employeesRequests' component={EmployeeComponent} />
          </Switch>
        </div>
        <FooterComponent />
      </Router>
    </Security>
  );
}

export default App;
