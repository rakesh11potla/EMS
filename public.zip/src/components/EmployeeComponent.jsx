import React, { useState, useEffect } from 'react';
import EmployeeService from '../services/EmployeeService';
import { useOktaAuth } from '@okta/okta-react';

const EmployeeComponent = () => {
    const { authState } = useOktaAuth();
    const [employee, setEmployee] = useState({});
    const [dataFound, setDataFound] = useState(true);

    useEffect(() => {
        if (authState && authState.isAuthenticated) {
            const email = authState.accessToken.claims.sub;
            EmployeeService.getEmployeeByEmail(email).then(res => {
                if (res.data) {
                    setEmployee(res.data);
                } else {
                    setDataFound(false);
                }
            }).catch(err => {
                console.error("Error fetching employee data:", err);
                setDataFound(false);
            });
        }
    }, [authState]);

    const [request, setRequest] = useState({
        firstName: '',
        lastName: '',
        emailId: authState.accessToken.claims.sub 
    });
    
    const handleChange = (e) => {
        const { name, value } = e.target;
        setRequest(prevState => ({
            ...prevState,
            [name]: value
        }));
    };
    
    const handleSubmit = async (event) => {
        event.preventDefault();
        try {
            const response = await EmployeeService.sendEmployeeRequest(request);
            if (response.status === 200 || response.status === 201) {
                alert('Request sent to admin successfully!');
            } else {
                throw new Error('Failed to send request: ' + response.data.message);
            }
        } catch (error) {
            console.error("Error sending request to admin:", error);
            alert('Failed to send request: ' + error.message);
        }
    };
    

    return (
        <div className="container mt-4">
            {dataFound ? (
                <div className="card">
                    <div className="card-header bg-primary text-white">
                        <h3 className="text-center">Profile Details</h3>
                    </div>
                    <div className="card-body">
                        <div className="mb-3 row">
                            <label className="col-sm-4 col-form-label">Employee First Name :</label>
                            <div className="col-sm-8">
                                <input type="text" readOnly className="form-control-plaintext" value={employee.firstName || ''} />
                            </div>
                        </div>
                        <div className="mb-3 row">
                            <label className="col-sm-4 col-form-label">Employee Last Name :</label>
                            <div className="col-sm-8">
                                <input type="text" readOnly className="form-control-plaintext" value={employee.lastName || ''} />
                            </div>
                        </div>
                        <div className="mb-3 row">
                            <label className="col-sm-4 col-form-label">Employee Email ID :</label>
                            <div className="col-sm-8">
                                <input type="text" readOnly className="form-control-plaintext" value={employee.emailId || ''} />
                            </div>
                        </div>
                    </div>
                </div>
            ) : (
                <div className="card">
                    <div className="card-header bg-danger text-white">
                        <h3 className="text-center">Employee Profile Not Found</h3>
                    </div>
                    <div className="card-body">
                        <p>Please note that the employee account has not yet been created.</p>
                        <p>Kindly submit a request to the administrator to facilitate the creation of the account. </p>
                        <br/>
                        <p>Please ensure to include the following details in your request:</p>
                        <form onSubmit={handleSubmit}>
                            <div className="mb-3 row">
                                <label className="col-sm-4 col-form-label">Employee First Name :</label>
                                <div className="col-sm-8">
                                    <input type="text" className="form-control" name="firstName" placeholder="Enter First Name" required onChange={handleChange} />
                                </div>
                            </div>
                            <div className="mb-3 row">
                                <label className="col-sm-4 col-form-label">Employee Last Name :</label>
                                <div className="col-sm-8">
                                    <input type="text" className="form-control" name="lastName" placeholder="Enter Last Name" required onChange={handleChange} />
                                </div>
                            </div>
                            <div className="mb-3 row">
                                <label className="col-sm-4 col-form-label">Employee Email ID :</label>
                                <div className="col-sm-8">
                                    <input type="email" className="form-control" value={authState.accessToken.claims.sub} disabled />
                                </div>
                            </div>
                            <div className="d-grid gap-2">
                                <button type="submit" className="btn btn-success">Send Request</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default EmployeeComponent;
