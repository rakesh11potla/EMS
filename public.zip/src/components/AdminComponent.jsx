import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AdminComponent = () => {
    const [requests, setRequests] = useState([]);

    // Function to fetch employee requests
    const fetchRequests = async () => {
        try {
            const response = await axios.get('http://localhost:8080/api/v1/employeeRequests');
            setRequests(response.data);
        } catch (error) {
            console.error('Failed to fetch employee requests:', error);
        }
    };

    // Function to approve an employee request
    const approveRequest = async (id) => {
        try {
            await axios.put(`http://localhost:8080/api/v1/employeeRequests/${id}/approve`);
            // Optionally remove the request from the list or fetch again
            fetchRequests(); // This will refetch the requests if you want to update the list
        } catch (error) {
            console.error('Failed to approve request:', error);
        }
    };

    useEffect(() => {
        fetchRequests();
    }, []);

    return (
        <div>
            <br/>
            <h2>Employee Creation/Modification Requests</h2>
            {requests.length > 0 ? (
                requests.map((request, index) => (
                    <div key={index}>
                        <p>First Name : {request.firstName}</p>
                        <p>Last Name :{request.lastName}</p>
                        <p>Email : {request.emailId}</p> 
                        <button onClick={() => approveRequest(request.id)}>Approve</button>
                    </div>
                ))
            ) : (
                <div>
                    <br/>
                    <p>No employee requests to display.</p>
                </div>
            )}
        </div>
    );
};

export default AdminComponent;
