import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AdminComponent = () => {
    const [requests, setRequests] = useState([]);

    const fetchRequests = async () => {
        try {
            const response = await axios.get('http://localhost:8080/api/v1/employeeRequests');
            setRequests(response.data.map(request => ({
                ...request,
                isProcessed: request.approved !== null
            })));
        } catch (error) {
            console.error('Failed to fetch employee requests:', error);
        }
    };

    const handleRequestAction = async (id, action) => {
        try {
            const endpoint = `http://localhost:8080/api/v1/employeeRequests/${id}/${action}`;
            await axios.put(endpoint);
            const updatedRequests = requests.map(req => {
                if (req.id === id) {
                    return {
                        ...req,
                        approved: action === 'approve',
                        isProcessed: true
                    };
                }
                return req;
            });
            setRequests(updatedRequests);
        } catch (error) {
            console.error(`Failed to ${action} request:`, error);
        }
    };

    useEffect(() => {
        fetchRequests();
    }, []);

    return (
        <div className="container mt-5">
            <h2 className="mb-4 text-center">Employee Creation/Modification Requests</h2>
            {requests.length > 0 ? (
                <div className="list-group">
                    {requests.map((request) => (
                        <div key={request.id} className="list-group-item list-group-item-action flex-column align-items-start">
                            <div className="d-flex w-100 justify-content-between">
                                <h5 className="mb-1">First Name :  {request.firstName}</h5>
                                <h5 className="mb-1">Last Name : {request.lastName}</h5>
                                <h5 className="mb-1">Email Id : {request.emailId}</h5>
                                <h5 className="mb-1">Date Of Birth : {request.dateOfBirth}</h5>
                            </div>
                            <p className="mb-1">Status: {request.approved === null ? "Pending" : request.approved ? "Approved" : "Rejected"}</p>
                            {!request.isProcessed && (
                                <div className="btn-group mt-2">
                                    <button onClick={() => handleRequestAction(request.id, 'approve')} className="btn btn-success">Approve</button>
                                    <button onClick={() => handleRequestAction(request.id, 'reject')} className="btn btn-danger">Reject</button>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            ) : (
                <div className="alert alert-info" role="alert">
                    No employee requests to display.
                </div>
            )}
        </div>
    );
};

export default AdminComponent;
