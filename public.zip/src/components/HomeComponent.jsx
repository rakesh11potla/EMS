// HomeComponent.js
import React from 'react';
import { useOktaAuth } from '@okta/okta-react';
import EmployeeComponent from './EmployeeComponent';



const HomeComponent = () => {
  const { authState } = useOktaAuth();

  return (
    <div className="text-center mt-5">
      {authState && authState.isAuthenticated ? (
        <div>
          <EmployeeComponent/>
        </div>
      ) : (
        <div>
            <h2>Welcome to Employee Management System</h2>
            <br/>
            <br/>
            <h2>Please log in to access the Employee Data</h2>
        </div>
      )}
      {/* Add any content or features you want to display on the home page */}
    </div>
  );
}

export default HomeComponent;
