import React from 'react';
import { Link, useHistory} from 'react-router-dom';
import { useOktaAuth } from '@okta/okta-react';
import { SpinnerLoading } from './SpinnerLoading';

const HeaderComponent = () => {
  const { authState, oktaAuth } = useOktaAuth();
  const history = useHistory(); 

  if (!authState) {
    return <SpinnerLoading />;
  }

  const handleLogout = async () => {
    oktaAuth.signOut();
    history.push('/home');
  };

  return (
    <header>
      <nav className="navbar navbar-expand-md navbar-dark bg-dark">
        <div>
          <Link to="/home" className="navbar-brand">Employee Management App</Link>
        </div>
        <div className="collapse navbar-collapse">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item">
              <Link to="/home" className="nav-link">Home</Link>
            </li>
            {authState.isAuthenticated && (
              <>
                {authState.accessToken?.claims?.userType === 'admin' && (
                  <li className="nav-item">
                    <Link to="/admin" className="nav-link">Admin</Link>
                  </li>
                )}
                <li className="nav-item">
                  <Link to="/employees" className="nav-link">Employees</Link>
                </li>
              </>
            )}
          </ul>
          <ul className="navbar-nav ml-auto">
            {!authState.isAuthenticated ? (
              <li className="nav-item">
                <Link type='button' to="/login" className="nav-link">Sign In</Link>
              </li>
            ) : (
              <li className="nav-item">
                <button onClick={handleLogout} className="btn btn-link nav-link">Logout</button>
              </li>
            )}
          </ul>
        </div>
      </nav>
    </header>
  );
};

export default HeaderComponent;
