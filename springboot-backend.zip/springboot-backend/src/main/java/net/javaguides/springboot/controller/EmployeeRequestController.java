package net.javaguides.springboot.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import net.javaguides.springboot.model.EmployeeRequest;
import net.javaguides.springboot.repository.EmployeeRequestRepository;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1")
public class EmployeeRequestController {

    @Autowired
    private EmployeeRequestRepository employeeRequestRepository;

    // Post a new employee creation request
    @PostMapping("/employeeRequests")
    public ResponseEntity<EmployeeRequest> createEmployeeRequest(@RequestBody EmployeeRequest employeeRequest) {
        if (employeeRequest.getApproved() == null) {
            employeeRequest.setApproved(false);  // Set default if null
        }
        EmployeeRequest savedRequest = employeeRequestRepository.save(employeeRequest);
        return ResponseEntity.ok(savedRequest);
    }

    
    @GetMapping("/employeeRequests")
    public List<EmployeeRequest> getAllEmployeeRequests() {
        return employeeRequestRepository.findAll();
    }
    

    @PutMapping("/{id}/approve")
    public ResponseEntity<?> approveEmployeeRequest(@PathVariable Long id) {
        Optional<EmployeeRequest> employeeRequestOptional = employeeRequestRepository.findById(id);
        if (employeeRequestOptional.isPresent()) {
            EmployeeRequest employeeRequest = employeeRequestOptional.get();
            employeeRequest.setApproved(true);  // Assuming there's a field 'approved' in EmployeeRequest
            employeeRequestRepository.save(employeeRequest);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
